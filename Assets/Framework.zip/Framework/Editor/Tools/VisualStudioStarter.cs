﻿using UnityEditor;
using UnityEngine;

namespace Framework.Editor.Tools
{
    public class VisualStudioStarter
    {
        [MenuItem("Framework/Editor/Open Visual Studio %&s")]
        public static void VsStarter()
        {
            string path = Application.dataPath.Replace("\\", "/");
            path = path.Replace("/Assets", string.Empty);
            
            if(path.Contains(":"))
            {
                SystemProcess.Start(@"C:\Program Files (x86)\Microsoft Visual Studio 14.0\Common7\IDE\devenv.exe", path + "/TriPeaks.sln");
            }
            else
            {
                SystemProcess.Start(@"/Applications/Visual Studio.app", path + "/Assembly-CSharp.sln");
            } 
        }
    }
}

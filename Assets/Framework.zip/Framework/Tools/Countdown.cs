﻿using System;
using System.Collections;
using UnityEngine;

namespace Framework.Tools
{
    public static class TimeUtility
    {
        public enum TimeType
        {
            hhmmss,
            mmss,
            ss
        }

        public class Countdown
        {
            private MonoBehaviour mono;
            private IEnumerator coroutine;
            private int leftTime;

            private Action<int> timerAction;
            private Action<int, string> timerMultiAction;
            private Action finishAction;

            private TimeType type;

            private WaitForSeconds wait;

            private Countdown(MonoBehaviour InMono, int InTime)
            {
                mono = InMono;
                leftTime = InTime;

                wait = new WaitForSeconds(1);
            }

            public Countdown(MonoBehaviour InMono, int InTime, Action InFinishAction)
                : this(InMono, InTime)
            {
                finishAction = InFinishAction;

                coroutine = Timer();
                mono.StartCoroutine(coroutine);
            }

            private IEnumerator Timer()
            {
                while (leftTime > 0)
                {
                    yield return wait;
                    --leftTime;
                }
                leftTime = 0;

                finishAction();
            }
            
            public Countdown(MonoBehaviour InMono, int InTime, Action<int> InTimer,
                Action InFinishAction)
                : this(InMono, InTime)
            {
                timerAction = InTimer;
                finishAction = InFinishAction;

                coroutine = CountdownInt();
                mono.StartCoroutine(coroutine);
            }

            private IEnumerator CountdownInt()
            {
                while (leftTime > 0)
                {
                    timerAction(leftTime);
                    yield return wait;
                    --leftTime;
                }

                leftTime = 0;
                timerAction(0);
                finishAction();
            }

            public Countdown(MonoBehaviour InMono, int InTime, TimeType InType,
                Action<int, string> InMultiTimer,
                Action InFinishAction)
                : this(InMono, InTime)
            {
                type = InType;
                timerMultiAction = InMultiTimer;
                finishAction = InFinishAction;

                coroutine = CountdownMutiTimer();
                mono.StartCoroutine(coroutine);
            }

            private IEnumerator CountdownMutiTimer()
            {
                switch (type)
                {
                    case TimeType.mmss:
                        {
                            int minute, second;
                            while (leftTime > 0)
                            {
                                minute = leftTime % 3600 / 60;
                                second = leftTime % 60;
                                timerMultiAction(leftTime, (minute > 9 ? "" : "0") + minute + (second > 9 ? ":" : ":0") + second);
                                yield return wait;
                                --leftTime;
                            }
                            timerMultiAction(0, "00:00");
                        }
                        break;

                    case TimeType.hhmmss:
                        {
                            int hour, minute, second;
                            while (leftTime > 0)
                            {
                                hour = leftTime / 3600;
                                minute = leftTime % 3600 / 60;
                                second = leftTime % 60;
                                timerMultiAction(leftTime, (hour > 9 ? "" : "0") + hour + (minute > 9 ? ":" : ":0") + minute + (second > 9 ? ":" : ":0") + second);
                                yield return wait;
                                --leftTime;
                            }
                            timerMultiAction(0, "00");
                        }
                        break;
                    case TimeType.ss:
                        while (leftTime > 0)
                        {
                            timerMultiAction(leftTime, leftTime > 9 ? leftTime.ToString() : "0" + leftTime);
                            yield return wait;
                            --leftTime;
                        }

                        timerMultiAction(0, "00:00:00");
                        break;
                }

                finishAction();
            }

            public void ResetTime(int InTime)
            {
                leftTime = InTime;

                if (null != timerAction) timerAction(leftTime);
                if (null != timerMultiAction) timerMultiAction(leftTime, ConvertToTime(leftTime, type));
            }

            public int AddTime(int InTime)
            {
                leftTime += InTime;

                if (null != timerAction) timerAction(leftTime);
                if (null != timerMultiAction) timerMultiAction(leftTime, ConvertToTime(leftTime, type));

                return leftTime;
            }

            public int SubTime(int InTime)
            {
                leftTime -= InTime;

                if (null != timerAction) timerAction(leftTime);
                if (null != timerMultiAction) timerMultiAction(leftTime, ConvertToTime(leftTime, type));

                return leftTime;
            }

            public int Pause()
            {
                if (null != coroutine)
                {
                    mono.StopCoroutine(coroutine);
                }

                return leftTime;
            }

            public void Resume()
            {
                if (leftTime > 0) mono.StartCoroutine(coroutine);
                else if (null != coroutine) coroutine = null;
            }

            public int Stop()
            {
                if (null != coroutine)
                {
                    mono.StopCoroutine(coroutine);
                    coroutine = null;
                }

                return leftTime;
            }
        }

        public static string ConvertToTime(int InTime, TimeType InType = TimeType.hhmmss)
        {
            if (TimeType.hhmmss == InType)
            {
                int hour = InTime / 3600;
                int minute = InTime % 3600 / 60;
                int second = InTime % 60;
                return (hour > 9 ? "" : "0") + hour + (minute > 9 ? ":" : ":0") + minute + (second > 9 ? ":" : ":0") + second;
            }
            else if (TimeType.mmss == InType)
            {
                int minute = InTime % 3600 / 60;
                int second = InTime % 60;
                return (minute > 9 ? "" : "0") + minute + (second > 9 ? ":" : ":0") + second;
            }

            return InTime > 9 ? InTime.ToString() : "0" + InTime;
        }
    }

}

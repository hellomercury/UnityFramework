﻿using System;
using System.Collections.Generic;
using Framework.SQLite3;
using Framework.Tools;
using UnityEngine;

namespace Framework.Test
{
    public class Test : MonoBehaviour
    {
        private TimeUtility.Countdown countdown;
        void OnGUI()
        {
            GUI.skin.button.fontSize = 64;
            if (GUILayout.Button("W"))
            {
                countdown = new TimeUtility.Countdown(this, 10, (time)=> {Debug.LogError(time);}, ()=> {Debug.LogError("Finished.");});
            }

            if (GUILayout.Button("Set"))
            {
                countdown.ResetTime(15);
            }

            if (GUILayout.Button("Add"))
            {
                countdown.AddTime(15);
            }

            if (GUILayout.Button("Sub"))
            {
                countdown.SubTime(15);
            }

            if (GUILayout.Button("P"))
            {
                countdown.Pause();
            }

            if (GUILayout.Button("R"))
            {
                countdown.Resume();
            }

            if (GUILayout.Button("S"))
            {
                countdown.Stop();
            }
        }

        void OnApplicationQuit()
        {
            DynamicData.GetInstance().CloseDB();
        }


        private Level currentLevelData;
        private int failCountTemp = 1;
        private List<int> GetFailCard()
        {
            int failCount = PlayerPrefs.GetInt("Level_" + currentLevelData.ID, 0);

            if (failCount >= currentLevelData.DynamicStartPoint)
            {
                failCount -= currentLevelData.DynamicStartPoint;
                string[] dynamicStartPsbStr = currentLevelData.DynamicStartPsb.Split('|');
                float dyanmicStartPsb = failCount < dynamicStartPsbStr.Length
                    ? Convert.ToSingle(dynamicStartPsbStr[failCount])
                    : 1;

                if (Utility.BinaryChoice(dyanmicStartPsb))
                {
                    int dynamicItemCount;
                    if (currentLevelData.DynamicItemTypeNum.Contains("|"))
                    {
                        int[] itemCount = Array.ConvertAll(currentLevelData.DynamicItemTypeNum.Split('|'),
                            Convert.ToInt32);
                        float[] itemCountPsb = Array.ConvertAll(currentLevelData.DynamicItemTypeNumPsb.Split('|'),
                            Convert.ToSingle);

                        dynamicItemCount = Utility.RandomWithWeight(itemCount, itemCountPsb);
                    }
                    else dynamicItemCount = 1;

                    int[] itemType = Array.ConvertAll(currentLevelData.DynamicItem.Split('|'), Convert.ToInt32);
                    float[] itemTypePsb = Array.ConvertAll(currentLevelData.DynamicItemPsb.Split('|'), Convert.ToSingle);

                    int[] itemIDIndexes = Utility.RandomWithWeightCanNotRepeatReturnIndex(itemType, itemTypePsb, dynamicItemCount);

                    string[] dynamicItemNums = currentLevelData.DynamicItemNum.Split('@');
                    string[] dynamicItemNumPsbs = currentLevelData.DynamicItemNumPsb.Split('@');

                    List<int> itemIDs = new List<int>(dynamicItemCount * 3);
                    for (int i = 0; i < dynamicItemCount; ++i)
                    {
                        if (dynamicItemNums[itemIDIndexes[i]].Contains("|"))
                        {
                            int[] itemTypeNums = Array.ConvertAll(dynamicItemNums[itemIDIndexes[i]].Split('|'),
                                Convert.ToInt32);
                            float[] itemTypeNumPsbs = Array.ConvertAll(dynamicItemNumPsbs[itemIDIndexes[i]].Split('|'),
                                Convert.ToSingle);
                            int count = Utility.RandomWithWeight(itemTypeNums, itemTypeNumPsbs);

                            for (int j = 0; j < count; ++j)
                            {
                                itemIDs.Add(itemType[itemIDIndexes[i]]);
                            }
                        }
                        else
                        {
                            int count = Convert.ToInt32(dynamicItemNums[itemIDIndexes[i]]);

                            for (int j = 0; j < count; ++j)
                            {
                                itemIDs.Add(itemType[itemIDIndexes[i]]);
                            }
                        }
                    }

                    return itemIDs;
                }
            }

            return null;
        }
    }

    [System.Serializable]
    public class STest
    {
        public int ID;

        public STest(int InID)
        {
            ID = InID;
        }
    }

    public class NTest
    {

    }
}

